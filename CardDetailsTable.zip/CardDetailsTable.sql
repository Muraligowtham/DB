use telecomm;
CREATE TABLE IF NOT EXISTS Familyuser (
Single_Id varchar(100),
Family_Id varchar(100),
FOREIGN KEY (Single_Id) REFERENCES singleuser(Userid) ,
FOREIGN KEY (Family_Id) REFERENCES Familyuser(Userid) ,
 CardNumber  int(200),
  CVV varchar(20),
  Expirydate varchar(20)
) 




