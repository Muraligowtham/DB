DELIMITER $$

Create procedure telecomm.CreateSingleUserProfile (
        IN  Single_Id                    varchar(100)       , 
		IN  password                    varchar(100)       ,         
        IN  SSN                    varchar(200), 
        IN  Name                      VARCHAR(100)   , 
        IN  addressline1                     VARCHAR(200) , 
        IN  addressline2                   VARCHAR(200)    ,
        IN  city                   VARCHAR(100)    , 
        IN  zip                    int(50)   ,
        IN  state                   VARCHAR(100)    , 
        IN  Country                   VARCHAR(100),
        IN PhoneNumber				int(50)
        
     )
Begin
Insert into user(Single_Id,SSN,Name,addressline1,addressline2,city,zip,state,country) values(Single_Id,SSN,Name,addressline1,addressline2,city,zip,state,country);
Insert into SingleUSer(Single_Id,password,phonenumber) values(Single_Id,password,phonenumber);
end$$