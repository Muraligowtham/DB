use telecomm;
CREATE TABLE IF NOT EXISTS Familyuser (
  Userid varchar(200) primary key,
  Password varchar(20)   
) 




