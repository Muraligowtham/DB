DELIMITER //


Create procedure telecomm.Inser (
        IN  Cardnumber                    int(100)       , 
		IN  cvv                   		  varchar(100)       ,         
        IN  ExpiryDate                    varchar(200), 
        IN  Single_UId                    varchar(100)  
     )
Begin

Insert into user(Cardnumber,cvv,ExpiryDate) values(Cardnumber,cvv,ExpiryDate) where user.Single_Id= Single_UId;
end//
DELIMITER ;