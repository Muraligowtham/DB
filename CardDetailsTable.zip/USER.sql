use telecomm;

CREATE TABLE IF NOT EXISTS User (
Single_Id varchar(100),
Family_Id varchar(100),
FOREIGN KEY (Single_Id) REFERENCES singleuser(Userid) ,
FOREIGN KEY (Family_Id) REFERENCES Familyuser(Userid) ,
SSN varchar(200) primary key,
Name varchar(200) not null,
addressline1 varchar(200) not null,
addressline2 varchar(200),
city varchar(100) not null,
zip int(10) not null,
state varchar(200) not null,
country varchar(200) not null, 
 CardNumber varchar(200) not null,
  CVV varchar(20) not null ,
  ExpiryDate int(20) not null

) 




