use telecomm;

CREATE TABLE IF NOT EXISTS singleuser (
  Userid varchar(200) primary key,
  Password varchar(20) not null ,
  phonenumber int(20) not null
) 




